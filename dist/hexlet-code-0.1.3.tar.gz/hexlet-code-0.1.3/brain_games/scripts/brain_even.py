#!/usr/bin/env python
import brain_games.question


def main():
    print('Welcome to the Brain Games!')
    brain_games.question.ask_user()


if __name__ == '__main__':
    main()
